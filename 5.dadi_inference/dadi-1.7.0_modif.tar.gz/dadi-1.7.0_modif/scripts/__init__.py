"""
Useful scripts for working with dadi.

ms_jsfs: Parse ms output to generate a joint SFS.
"""
